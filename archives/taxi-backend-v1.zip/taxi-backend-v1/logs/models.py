from django.contrib.gis.db import models as gis_models
from django.core.exceptions import ValidationError
from django.db import models


# =====================================================================
# نماذج التسعير - مستخلصة من مسح تنظيمي لـ11 دولة عربية و14 سوقًا عالمية.
#
# القاعدة التي حكمت التصميم: لا توجد دولة تمنع "مزايدة السائقين" بالاسم.
# الخطر يأتي من *التعارض مع تعرفة إلزامية قائمة* (سابقة الفلبين 2024).
# لذلك الخطط ليست مستويات تصاعدية، بل آليات مستقلة يُفعَّل منها ما يوافق
# قانون البلد - وقد تُفعَّل أكثر من واحدة معًا.
# =====================================================================


class PricingPolicy(models.TextChoices):
    PLATFORM_FIXED = "platform_fixed", "سعر المنصة الثابت (أوبر/كريم)"
    REGULATED_TARIFF = "regulated_tariff", "تعرفة رسمية إلزامية (الأردن/دبي)"
    TARIFF_CORRIDOR = "tariff_corridor", "ممر تعرفة: أرضية وسقف (الهند/إندونيسيا)"
    DRIVER_BIDDING = "driver_bidding", "مزايدة السائقين (السائق يقترح سعره)"
    CUSTOMER_BIDDING = "customer_bidding", "الزبون يقترح السعر (نموذج inDrive)"


class SurgeMode(models.TextChoices):
    DISABLED = "disabled", "معطّل"
    CAPPED = "capped", "خوارزمي بسقف أقصى"
    REGULATOR_TIERS = "regulator_tiers", "نوافذ ورسوم تحددها الهيئة (دبي)"
    FREE = "free", "خوارزمي بلا سقف"


class PriceChangeWorkflow(models.TextChoices):
    NONE = "none", "بلا إجراء"
    NOTIFY = "notify", "إخطار مسبق للجهة المنظِّمة (مصر)"
    APPROVAL = "approval", "موافقة مسبقة قبل التفعيل (السعودية)"


class SharedDestinationPrecision(models.IntegerChoices):
    """
    دقّة تقريب وجهة الركّاب الحاليين المعروضة لمرشّح الانضمام في الرحلات
    المشتركة. الأدمن يختار حسب كثافة مدينته - لكن ليس أدقّ من 6.

    عمدًا لا نسمح بـ7 (~150م) ولا 8 (~38م): هذه دقّة تكشف حيًّا بعينه أو
    مبنى، وتحوّل الخريطة من خدمة إلى أداة تتبّع. حاجز على مستوى الموديل،
    لا على مستوى الاتفاق.
    """
    COARSE = 4, "~20 كم — حماية قصوى (كثافة منخفضة/ريف)"
    BALANCED = 5, "~5 كم — متوازن (الافتراضي)"
    FINE = 6, "~1.2 كم — فلترة دقيقة (مدن مزدحمة)"


class ServiceArea(models.Model):
    """
    منطقة خدمة مستقلة (مدينة/محافظة) تُدار بالكامل من لوحة الإدارة.

    القرار المعماري: لا شيء خاص بمدينة أو بدولة مكوَّد يدويًا في أي مكان.
    إضافة سوق جديد = صف جديد هنا بإعداداته، بلا تعديل كود ولا نشر.
    """

    # -----------------------------------------------------------------
    # الهوية
    # -----------------------------------------------------------------

    code = models.CharField(
        max_length=10,
        unique=True,
        help_text="رمز قصير فريد يظهر داخل area_id، مثال: JAB, LAT, DAM",
    )

    name = models.CharField(max_length=100)

    country_code = models.CharField(
        max_length=2,
        blank=True,
        help_text="ISO 3166-1 alpha-2، مثال: SY, JO, AE. للتقارير والامتثال.",
    )

    currency_code = models.CharField(
        max_length=3,
        default="SYP",
        help_text="ISO 4217. كل المبالغ في هذه المنطقة بهذه العملة.",
    )

    # -----------------------------------------------------------------
    # الحدود الجغرافية
    # -----------------------------------------------------------------

    boundary = gis_models.PolygonField(
        geography=True,
        srid=4326,
        null=True,
        blank=True,
        help_text=(
            "حدود المدينة الدقيقة (Polygon). اتركها فارغة واستخدم "
            "center + fallback_radius_km كبديل دائري مؤقت لحين توفرها."
        ),
    )

    center = gis_models.PointField(
        geography=True,
        srid=4326,
        null=True,
        blank=True,
    )

    fallback_radius_km = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        default=15,
        help_text="يُستخدم فقط إذا لم تُحدَّد boundary دقيقة لهذه المدينة.",
    )

    # -----------------------------------------------------------------
    # الخريطة الحيّة
    # -----------------------------------------------------------------

    marketplace_cell_precision = models.PositiveSmallIntegerField(
        default=7,
        help_text=(
            "دقة خلايا geohash لهذه المدينة (عمليًا 5–8). "
            "5≈4.9كم · 6≈1.2كم · 7≈150م · 8≈38م"
        ),
    )

    shared_destination_precision = models.PositiveSmallIntegerField(
        choices=SharedDestinationPrecision.choices,
        default=SharedDestinationPrecision.BALANCED,
        help_text=(
            "كم نُقرِّب وجهة الركّاب الحاليين عند عرض سيارة مشتركة "
            "لمرشّح انضمام. كلما زادت الدقّة تحسّنت الفلترة وقلّت الخصوصية."
        ),
    )

    shared_min_compatibility_score = models.PositiveSmallIntegerField(
        default=55,
        help_text=(
            "أقل درجة توافق (من 100) تُظهر سيارة مشتركة كخيار صالح. "
            "أقل = مطابقات أكثر وانعراج أكبر."
        ),
    )

    # -----------------------------------------------------------------
    # المطابقة
    # -----------------------------------------------------------------

    default_matching_radius_km = models.DecimalField(
        max_digits=6, decimal_places=2, default=5,
    )

    # -----------------------------------------------------------------
    # الدعوة المباشرة (خريطة السيارات الحيّة)
    # -----------------------------------------------------------------

    invitation_ttl_options = models.JSONField(
        default=list,
        blank=True,
        help_text=(
            "المهل (بالثواني) التي تُعرض على الزبون ليختار منها قبل إرسال "
            'الدعوة. مثال: [20, 40, 60]. القيمة خارج القائمة تُرفض من الخادم.'
        ),
    )

    invitation_ttl_default = models.PositiveSmallIntegerField(
        default=20,
        help_text="المهلة المختارة مسبقًا. يجب أن تكون ضمن القائمة أعلاه.",
    )

    invitation_max_parallel = models.PositiveSmallIntegerField(
        default=1,
        help_text=(
            "كم دعوة يمكن للزبون إرسالها في وقت واحد للطلب نفسه. "
            "1 = سيارة واحدة ثم انتظار (الموصى به وما تنص عليه الوثيقة)."
        ),
    )

    invitation_allowed_modes = models.JSONField(
        default=list,
        blank=True,
        help_text=(
            "أنماط الخدمة التي تُفعَّل فيها الخريطة الحيّة والدعوة المباشرة. "
            'مثال: ["fast", "express"] أو أضف "shared" لتفعيل المشتركة.'
        ),
    )

    # -----------------------------------------------------------------
    # التسعير - القلب الجديد
    # -----------------------------------------------------------------

    allowed_pricing_policies = models.JSONField(
        default=list,
        blank=True,
        help_text=(
            "خطط التسعير المسموح بها في هذه المنطقة. يمكن اختيار أكثر من "
            "واحدة. اختر ما يوافق قانون البلد فعلًا."
        ),
    )

    default_pricing_policy = models.CharField(
        max_length=30,
        choices=PricingPolicy.choices,
        default=PricingPolicy.PLATFORM_FIXED,
        help_text="الخطة المطبَّقة تلقائيًا. يجب أن تكون ضمن المسموح بها.",
    )

    surge_mode = models.CharField(
        max_length=20,
        choices=SurgeMode.choices,
        default=SurgeMode.DISABLED,
        help_text=(
            "تنبيه: 'مسموح بالتسعير الديناميكي' و'المنصة تحسبه' شيئان "
            "مختلفان. دبي تسمح بالتغيّر لكن الهيئة هي من تحدد النوافذ والرسوم "
            "→ اختر regulator_tiers لا capped."
        ),
    )

    surge_max_multiplier = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="مطلوب مع surge_mode=capped. مثال: 2.00 (الهند)، 1.75 (مدريد).",
    )

    fare_floor_multiplier = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        null=True,
        blank=True,
        help_text=(
            "أرضية السعر كنسبة من تسعيرة المنصة. مطلوبة مع ممر التعرفة. "
            "مثال: 0.50 (الهند)، 0.93 (ألمانيا: حد أدنى لحماية التاكسي)."
        ),
    )

    fare_cap_multiplier = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="سقف السعر كنسبة من تسعيرة المنصة. مثال: 2.00 (الهند).",
    )

    min_fare_absolute = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="حد أدنى مطلق للأجرة بعملة المنطقة. مثال: 13 درهم في دبي.",
    )

    driver_min_share_pct = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="أقل نسبة يجب أن يقبضها السائق من الأجرة. مثال: 80 (الهند).",
    )

    commission_cap_pct = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="سقف عمولة المنصة. مثال: 15 (إندونيسيا)، 18 (كينيا). MVP=0.",
    )

    allow_renegotiation_after_match = models.BooleanField(
        default=False,
        help_text=(
            "هل يجوز تعديل السعر بعد تثبيت السائق؟ ماليزيا تحظره صراحةً. "
            "اتركه معطّلًا ما لم يكن مسموحًا صراحةً."
        ),
    )

    price_change_workflow = models.CharField(
        max_length=20,
        choices=PriceChangeWorkflow.choices,
        default=PriceChangeWorkflow.NONE,
        help_text=(
            "الفرق تشغيلي جوهري: 'إخطار' يسجّل التغيير ويمضي، "
            "'موافقة' يحجب التفعيل حتى ردّ الجهة."
        ),
    )

    # -----------------------------------------------------------------
    # سجل الامتثال - ليس منطقًا، لكنه يوفّر ساعات عند أي مراجعة قانونية
    # -----------------------------------------------------------------

    regulator_name = models.CharField(
        max_length=150,
        blank=True,
        help_text="مثال: هيئة تنظيم النقل البري (LTRC) — الأردن",
    )

    legal_reference = models.CharField(
        max_length=255,
        blank=True,
        help_text="رقم القانون/اللائحة التي بُنيت عليها الإعدادات أعلاه.",
    )

    compliance_note = models.TextField(
        blank=True,
        help_text=(
            "ملاحظات المراجعة القانونية. إن كان الوضع التنظيمي غامضًا "
            "(قطر/الكويت/سوريا) سجّل ذلك هنا صراحةً - الصمت ليس إذنًا."
        ),
    )

    # -----------------------------------------------------------------
    # معايرة التقدير الداخلي للمسافة والزمن
    #
    # تُستخدم حين يتعذّر مزوّد التوجيه (راجع maps/services/routing.py).
    # قيمتان لكلّ منطقة لا قيمة عالمية: التفاف شوارع جبلة الساحلية ليس
    # التفاف شبكة دمشق، وسرعة الذروة في مدينة صغيرة ليست سرعة العاصمة.
    # عايرهما بمقارنة عيّنة من الرحلات الحقيقية بالمسافة الهوائية.
    # -----------------------------------------------------------------

    road_detour_factor = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        null=True,
        blank=True,
        help_text=(
            "نسبة مسافة الطريق إلى المسافة الهوائية. 1.35 نقطة بداية "
            "معقولة لمدينة ساحلية. اتركه فارغًا لاستخدام الافتراضي العام."
        ),
    )

    average_speed_kmh = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text=(
            "السرعة الوسطية الفعلية بما فيها التوقّف والإشارات — لا الحدّ "
            "الأقصى المسموح. 30 كم/سا نقطة بداية معقولة."
        ),
    )

    is_active = models.BooleanField(default=True, db_index=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"ServiceArea({self.code} - {self.name})"

    # -----------------------------------------------------------------
    # DEFAULTS
    # -----------------------------------------------------------------

    @staticmethod
    def default_invitation_ttl_options():
        return [20, 40, 60]

    @staticmethod
    def default_invitation_allowed_modes():
        return ["fast", "express"]

    @staticmethod
    def default_pricing_policies():
        return [PricingPolicy.PLATFORM_FIXED, PricingPolicy.DRIVER_BIDDING]

    def save(self, *args, **kwargs):
        # JSONField(default=list) يعطي قائمة فارغة، وهي ليست إعدادًا صالحًا.
        # نملأ الافتراضات المعقولة عند أول حفظ بدل ترك المنطقة معطّلة صامتًا.
        if not self.invitation_ttl_options:
            self.invitation_ttl_options = self.default_invitation_ttl_options()
        if not self.invitation_allowed_modes:
            self.invitation_allowed_modes = self.default_invitation_allowed_modes()
        if not self.allowed_pricing_policies:
            self.allowed_pricing_policies = self.default_pricing_policies()
        return super().save(*args, **kwargs)

    # -----------------------------------------------------------------
    # VALIDATION - تمنع تركيبات غير متسقة قبل أن تصل للإنتاج
    # -----------------------------------------------------------------

    def clean(self):
        errors = {}

        valid_policies = {c[0] for c in PricingPolicy.choices}
        policies = set(self.allowed_pricing_policies or [])

        unknown = policies - valid_policies
        if unknown:
            errors["allowed_pricing_policies"] = f"خطط غير معروفة: {sorted(unknown)}"

        if policies and self.default_pricing_policy not in policies:
            errors["default_pricing_policy"] = (
                "الخطة الافتراضية يجب أن تكون ضمن الخطط المسموح بها."
            )

        # تعرفة رسمية إلزامية + مزايدة = تناقض منطقي قبل أن يكون قانونيًا:
        # لا يوجد ما يُزايَد عليه إن كان السعر محددًا من الدولة.
        if PricingPolicy.REGULATED_TARIFF in policies and (
            PricingPolicy.DRIVER_BIDDING in policies
            or PricingPolicy.CUSTOMER_BIDDING in policies
        ):
            errors["allowed_pricing_policies"] = (
                "لا يمكن الجمع بين تعرفة رسمية إلزامية وأي شكل من المزايدة. "
                "إن أردت هامش تفاوض ضمن حدود رسمية استخدم 'ممر تعرفة' بدلًا منها."
            )

        if PricingPolicy.TARIFF_CORRIDOR in policies:
            if self.fare_floor_multiplier is None or self.fare_cap_multiplier is None:
                errors["fare_floor_multiplier"] = (
                    "ممر التعرفة يتطلب تحديد الأرضية والسقف معًا."
                )
            elif not (
                self.fare_floor_multiplier
                <= 1
                <= self.fare_cap_multiplier
            ):
                errors["fare_cap_multiplier"] = (
                    "يجب أن يتحقق: الأرضية ≤ 1.00 ≤ السقف "
                    "(تسعيرة المنصة هي المرجع الذي يدور حوله الممر)."
                )

        if self.surge_mode == SurgeMode.CAPPED and self.surge_max_multiplier is None:
            errors["surge_max_multiplier"] = (
                "الوضع 'خوارزمي بسقف' يتطلب تحديد السقف الأقصى."
            )

        if self.surge_mode == SurgeMode.DISABLED and self.surge_max_multiplier:
            errors["surge_max_multiplier"] = (
                "التسعير الديناميكي معطّل — اترك السقف فارغًا لتفادي الالتباس."
            )

        # الدعوات
        options = self.invitation_ttl_options or []
        if options:
            if not all(isinstance(v, int) and 5 <= v <= 300 for v in options):
                errors["invitation_ttl_options"] = (
                    "كل مهلة يجب أن تكون عددًا صحيحًا بين 5 و300 ثانية."
                )
            elif self.invitation_ttl_default not in options:
                errors["invitation_ttl_default"] = (
                    f"المهلة الافتراضية يجب أن تكون ضمن الخيارات {options}."
                )

        if self.invitation_max_parallel < 1:
            errors["invitation_max_parallel"] = "يجب أن تكون 1 على الأقل."

        if self.boundary is None and self.center is None:
            errors["center"] = (
                "حدّد إمّا boundary دقيقة أو center مع نصف قطر — "
                "وإلا لن تُحلّ أي نقطة إلى هذه المنطقة."
            )

        if errors:
            raise ValidationError(errors)

    # -----------------------------------------------------------------
    # القيم الفعلية
    #
    # درس مستفاد: الاعتماد على save() لتعبئة الافتراضات لا يكفي. الهجرة
    # تكتب default=list في الصفوف القائمة مباشرةً بلا استدعاء save()، فتبقى
    # المنطقة بقائمة فارغة إلى أن يحفظها أحد - وقائمة فارغة هنا تعني
    # "الدعوة المباشرة معطّلة في هذه المدينة"، وهو معنى لم يقصده أحد.
    #
    # لذلك القراءة نفسها تحمل الافتراض، لا الكتابة.
    # -----------------------------------------------------------------

    @property
    def effective_pricing_policies(self):
        return self.allowed_pricing_policies or self.default_pricing_policies()

    @property
    def effective_invitation_modes(self):
        return self.invitation_allowed_modes or self.default_invitation_allowed_modes()

    @property
    def effective_ttl_options(self):
        return self.invitation_ttl_options or self.default_invitation_ttl_options()

    @property
    def effective_ttl_default(self):
        options = self.effective_ttl_options
        if self.invitation_ttl_default in options:
            return self.invitation_ttl_default
        return options[0]

    # -----------------------------------------------------------------
    # HELPERS
    # -----------------------------------------------------------------

    def allows_policy(self, policy):
        return policy in self.effective_pricing_policies

    def allows_invitation_for_mode(self, mode):
        return mode in self.effective_invitation_modes

    def is_valid_invitation_ttl(self, seconds):
        try:
            return int(seconds) in self.effective_ttl_options
        except (TypeError, ValueError):
            return False
